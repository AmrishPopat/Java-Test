package com.penguin.amrishpopat.javaTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
