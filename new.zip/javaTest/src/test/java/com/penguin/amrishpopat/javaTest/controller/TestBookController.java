package com.penguin.amrishpopat.javaTest.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
 
//import java.util.Arrays;
 
import static org.hamcrest.Matchers.*;
import static org.hamcrest.Matchers.is;
//import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {TestContext.class, WebApplicationContext.class})
@WebAppConfiguration
public class TestBookController {
	
	@InjectMocks
	private BookController bookControllerMock;
	
	@Autowired 
	private MockMvc mockMvc;
	
	@Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(bookControllerMock).build();
    }
	
	@Test
	public void testGetBook() throws Exception {
        mockMvc.perform(get("/books"))
        .andExpect(status().isOk())
        .andExpect(view().name("books"))
        .andExpect(forwardedUrl("/WEB-INF/jsp/books.jsp"))
        .andExpect(model().attribute("books", hasSize(6)))
        .andExpect(model().attribute("books", hasItem(
                allOf(
                        hasProperty("id", is("11")),
                        hasProperty("description", is("Lorem ipsum")),
                        hasProperty("title", is("Foo"))
                )
        )))
        .andExpect(model().attribute("books", hasItem(
                allOf(
                        hasProperty("id", is("12")),
                        hasProperty("description", is("Lorem ipsum")),
                        hasProperty("title", is("Bar"))
                )
        )));
	}

}
