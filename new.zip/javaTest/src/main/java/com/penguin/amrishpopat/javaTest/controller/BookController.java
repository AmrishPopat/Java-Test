package com.penguin.amrishpopat.javaTest.controller;

//import java.net.MalformedURLException;
//import java.net.URL;
//import java.util.ArrayList;
//import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.penguin.amrishpopat.javaTest.DAO.BookDAO;
//import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.penguin.amrishpopat.javaTest.model.Book;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.bind.annotation.SessionAttributes;
import com.penguin.amrishpopat.javaTest.service.BookService;

@Controller
//@SessionAttributes("name")
//@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class BookController {
	
	@Autowired
	private BookService bookService;	

	
	@RequestMapping(value = "/books", method = RequestMethod.GET)
    //@ResponseBody
    public String getBook(ModelMap model) {    	 
    	 model.put("books123", bookService.getAllBooks()); 
    	 return "books";
    }

    @GetMapping("/books/{id}")
    //@ResponseBody
    public Book getBookById(@PathVariable String id) {
    	return bookService.getBook(id); 
    }
    
    @GetMapping("/index")
    //@ResponseBody
    public String getExample(){
        return "index.html";
    }
}

