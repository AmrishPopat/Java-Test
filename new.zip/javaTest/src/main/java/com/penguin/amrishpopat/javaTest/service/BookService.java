package com.penguin.amrishpopat.javaTest.service;

import java.util.List;
import org.springframework.stereotype.Service;
import com.penguin.amrishpopat.javaTest.DAO.BookDAO;
import com.penguin.amrishpopat.javaTest.model.Book;

@Service
public class BookService {
	
	
	public BookService() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	private BookDAO bookDAO = new BookDAO();

	private List<Book> books = bookDAO.readJson();
        
	/*
	 * private List<Book> books = Arrays.asList( new Book("1", "Title", "Author",
	 * "http://www.example.com"), new Book("2", "Title", "Author",
	 * "http://www.example.com"), new Book("3", "Title", "Author",
	 * "http://www.example.com"), new Book("4", "Title", "Author",
	 * "http://www.example.com") );
	 */
    
    public List<Book> getAllBooks() {
    	//if (null != books) {
    		return books;

    }
    
    public Book getBook(String id) {
    	return books.stream().filter(t -> t.getId().equals(id)).findFirst().get();
    }
}
