package com.penguin.amrishpopat.javaTest.DAO;

import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.penguin.amrishpopat.javaTest.model.Book;

@Component
public class BookDAO {

	public List<Book> readJson() {
		Gson gson = new GsonBuilder().create();
        
        //String fileName = "src\\main\\resources\\data.json";
        Path path = Paths.get("src\\main\\resources\\static\\data.json");
        //Path path = new File(fileName).toPath();
        System.out.println(path);
        
        List<Book> books = Arrays.asList( new Book("1", "Title", "Author",
			  "http://www.example.com"), new Book("2", "Title", "Author",
					  "http://www.example.com"), new Book("3", "Title", "Author",
				 "http://www.example.com"), new Book("4", "Title", "Author",
					  "http://www.example.com") );
       
        try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            
            Book[] booksArray = gson.fromJson(reader, Book[].class);
            Arrays.stream(booksArray).forEach( e -> {
                System.out.println("Each line" + e);
            });
            books = Arrays.asList(booksArray);
            
        } catch (IOException e) {
        	System.out.println("Unable to read data.json " + e.getMessage());
        }
        return books;
	}
}
